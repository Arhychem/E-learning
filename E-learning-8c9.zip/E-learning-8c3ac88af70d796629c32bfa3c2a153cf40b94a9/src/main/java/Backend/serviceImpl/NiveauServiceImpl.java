package Backend.serviceImpl;


import Backend.entities.Lecon;
import Backend.entities.Niveau;
import Backend.service.NiveauService;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class NiveauServiceImpl implements NiveauService {



    @Autowired
    NiveauServiceRepository niveauRepository;

    public List<Niveau> getNiveau() {
        return niveauRepository.findAll() ;
    }

    public  Niveau createNiveau(@RequestBody Niveau niveau)  {

        return leconRepository.save(niveau) ;

    }

    public  ResponseEntity<Niveau> getNiveauById(@pathVariable String niveauId)  {
        Niveau niveau = niveauRepository.findById(String niveauId) ;
        return ResponseEntity.ok(niveau) ;

    }

    public Map<String , Boolean> deleteNiveau (@pathVariable String niveauId ) {
        Niveau niveau = niveauRepository.findById(niveauId) ;
        niveauRepository.delete(niveau) ;
        Map<String, Boolean> reponse = new HashMap<>() ;
        reponse.put("deleted", Boolean.TRUE) ;

        return ResponseEntity.ok(reponse) ;
    }








}
