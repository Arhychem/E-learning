package Backend.serviceImpl;


import Backend.JWT.JwtFilter;
import Backend.JWT.JwtUtil;
import Backend.JWT.UsersDetailsService;
import Backend.entities.Lecon;
import Backend.repository.UserRepository;
import Backend.service.LeconService;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service

public class LeconServiceImpl implements LeconService {

    @Autowired
    LeconServiceRepository leconRepository;

    public List<Lecon> getLecon() {
        return leconRepository.findAll() ;
    }

    public  Lecon createLecon(@RequestBody Lecon lecon)  {

        return leconRepository.save(lecon) ;

    }

    public  ResponseEntity<Lecon> getLeconById(@pathVariable String leconId)  {
        Lecon lecon = leconRepository.findById(String leconId) ;
        return ResponseEntity.ok(lecon) ;

    }

    public Map<String , Boolean> deleteLecon (@pathVariable String leconId ) {
        Lecon lecon = leconRepository.findById(leconId) ;
        leconRepository.delete(lecon) ;
        Map<String, Boolean> reponse = new HashMap<>() ;
        reponse.put("deleted", Boolean.TRUE) ;

        return ResponseEntity.ok(reponse) ;
    }









}
