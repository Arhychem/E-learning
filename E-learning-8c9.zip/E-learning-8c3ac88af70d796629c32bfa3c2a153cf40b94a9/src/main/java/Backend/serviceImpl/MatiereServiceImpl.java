package Backend.serviceImpl;


import Backend.entities.Lecon;
import Backend.entities.Matiere;
import Backend.service.MatiereService;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class MatiereServiceImpl implements MatiereService {



    @Autowired
    MatiereServiceRepository matiereRepository;

    public List<Matiere> getMatiere() {
        return matiereRepository.findAll() ;
    }

    public  Lecon createMatiere(@RequestBody Matiere matiere)  {

        return matiereRepository.save(matiere) ;

    }

    public  ResponseEntity<Matiere> getMatiereById(@pathVariable String matiereId)  {
        Matiere matiere = matiereRepository.findById(String matiereId) ;
        return ResponseEntity.ok(matiere) ;

    }

    public Map<String , Boolean> deleteMatiere (@pathVariable String matiereId ) {
        Matiere matiere = matiereRepository.findById(matiereId) ;
        matiereRepository.delete(matiere) ;
        Map<String, Boolean> reponse = new HashMap<>() ;
        reponse.put("deleted", Boolean.TRUE) ;

        return ResponseEntity.ok(reponse) ;
    }






}
