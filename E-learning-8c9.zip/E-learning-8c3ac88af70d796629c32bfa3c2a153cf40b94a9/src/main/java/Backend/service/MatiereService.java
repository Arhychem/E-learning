package Backend.service;

import Backend.entities.Lecon;
import Backend.entities.Matiere;

import java.util.Map;

public interface MatiereService {


    List<Matiere> getMatiere() ;
    Lecon createMatiere(@RequestBody Matiere matiere) ;
    ResponseEntity<Matiere> getMatiereById(@pathVariable String MatiereId) ;
    ResponseEntity<Matiere> updateMatiere(@pathVariable String MatiereId , Matiere matiere) ;
    Map<String , Boolean> deleteMatiere (@pathVariable String MatiereId ) ;
}
