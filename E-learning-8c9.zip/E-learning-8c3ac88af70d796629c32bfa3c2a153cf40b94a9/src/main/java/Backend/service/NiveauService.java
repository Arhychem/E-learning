package Backend.service;


import Backend.entities.Lecon;
import Backend.entities.Matiere;
import Backend.entities.Niveau;

import java.util.Map;

@Service
public interface NiveauService {




    List<Niveau> getNiveau() ;
    Lecon createNiveau(@RequestBody Niveau niveau) ;
    ResponseEntity<Niveau> getNiveauById(@pathVariable String NiveauId) ;
    ResponseEntity<Niveau> updateNiveau(@pathVariable String NiveauId , Niveau niveau) ;
    Map<String , Boolean> deleteNiveau (@pathVariable String NiveauId ) ;

}
