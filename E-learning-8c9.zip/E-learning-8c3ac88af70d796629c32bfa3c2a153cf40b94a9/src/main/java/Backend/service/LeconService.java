package Backend.service;


import Backend.entities.Lecon;
import jdk.jfr.internal.Repository;

import java.util.Map;

@Service
public interface LeconService {

    ResponseEntity<String> signUp(Map<String, String> requestMap);

    List<Lecon> getLecon() ;
    Lecon createLecon(@RequestBody Lecon lecon) ;
    ResponseEntity<Lecon> getLeconById(@pathVariable String leconId) ;
    ResponseEntity<Lecon> updateLecon(@pathVariable String leconId , Lecon lecon) ;
    Map<String , Boolean> deleteLecon (@pathVariable String leconId ) ;
    ResponseEntity updateLecon(@pathVariable String leconId, @RequestBody LeconDetails) ;


}
