package Backend.repository;


@Repository
public interface MatiereRepository extends JpaRepository<Lecon, String>  {

}
