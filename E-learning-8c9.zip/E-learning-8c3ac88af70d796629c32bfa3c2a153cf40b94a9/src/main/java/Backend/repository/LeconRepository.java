package Backend.repository;

import Backend.entities.User;

@Repository
public interface LeconRepository extends JpaRepository<Lecon, String>  ²{

}
