package Backend.repository;


@Repository
public interface NiveauRepository extends JpaRepository<Lecon, String> {
}
