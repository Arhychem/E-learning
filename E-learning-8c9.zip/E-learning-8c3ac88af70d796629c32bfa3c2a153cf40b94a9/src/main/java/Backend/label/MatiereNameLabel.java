package Backend.label;

public enum MatiereNameLabel {
    MATHEMATIQUE,
    PHYSIQUE,
    CHIMIE,
    SVT,
    HISTOIRE,
    GEOGRAPHIE,
    ECM,
    PCT,
    FRANCAIS,
    LITTERATURE,
    LANGUE_FRANCAISE,
    ANGLAIS,
    INFORMATIQUE,
    ALLEMAND,
    ESPAGNOL,
    PHILOSOPHIE

}
