package Backend.label;

public enum CycleNameLabel {
    PREMIER_CYCLE,
    DEUXIEME_CYCLE
}
