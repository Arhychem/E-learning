package Backend.label;

public enum SysNameLabel {
    FRANCOPHONE,
    ANGLOPHONE,
    SYSTEME_EDUCATIF_CAMEROUNAIS
}
